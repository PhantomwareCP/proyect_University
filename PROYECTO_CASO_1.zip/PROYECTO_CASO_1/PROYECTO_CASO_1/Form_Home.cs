﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROYECTO_CASO_1
{
    public partial class Form_Home : Form
    {
        public Form_Home()
        {
            InitializeComponent();
        }
        //Hora y fecha
        private void Hora_Fecha_Tick(object sender, EventArgs e)
        {
            lb_hora.Text = DateTime.Now.ToString("hh:mm:ss");
            lb_fecha.Text = DateTime.Now.ToLongDateString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form_Login flog = new Form_Login();
            flog.Show();
            this.Hide();
        }

        //cuenta corriente
        private void but_Cuen_Corri_Click(object sender, EventArgs e)
        {
            Cuenta_Corriente fhcu = new Cuenta_Corriente();
            fhcu.Show();
            this.Hide();
        }
        //usuario
        private void but_Usuar_Click(object sender, EventArgs e)
        {
            Form_Usuario fhu = new Form_Usuario();
            fhu.Show();
            this.Hide();
        }
        //cuenta de ahorros
        private void but_cue_Ahorr_Click(object sender, EventArgs e)
        {
            Cuenta_Ahorros FH= new Cuenta_Ahorros();
            FH.Show();            
            this.Hide();
        }
        //cuenta plazo fijo
        private void but_Cuen_CPF_Click(object sender, EventArgs e)
        {
            Cuenta_a_plazo_fijo FH1 = new Cuenta_a_plazo_fijo();
            FH1.Show();          
            this.Hide();
        }
        

      
    }
}
