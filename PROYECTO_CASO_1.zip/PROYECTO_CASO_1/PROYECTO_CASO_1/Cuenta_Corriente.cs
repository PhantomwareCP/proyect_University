﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROYECTO_CASO_1
{
    public partial class Cuenta_Corriente : Form
    {
        public Cuenta_Corriente()
        {
            InitializeComponent();
        }
     
        private void but_Regresar_Click_1(object sender, EventArgs e)
        {
            Form_Home fh = new Form_Home();
            fh.Show();
            this.Hide();
        }
    }
}
